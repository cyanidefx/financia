const express = require('express');
const router = express.Router();
router.get('/', (req, res) => res.send('All expenses'));
router.post('/', (req, res) => res.send('Add expense'));
module.exports = router;