export default function Dashboard() {
    return (
        <div>
            <h1>Your Financial Dashboard</h1>
        </div>
    );
}