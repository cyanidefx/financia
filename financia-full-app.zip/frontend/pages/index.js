import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
    return (
        <div>
            <Head>
                <title>Financia</title>
            </Head>
            <main>
                <h1>Welcome to Financia</h1>
                <Link href="/dashboard">Go to Dashboard</Link>
            </main>
        </div>
    );
}